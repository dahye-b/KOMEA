package egovframework.komeaweb.com.service;

public class ExbiVO extends ShowVO {
	private static final long serialVersionUID = 1L;

}
